# Customer Churn Prediction and Segmentation System

An end-to-end machine learning system that (1) predicts whether a telecom
customer will churn and (2) segments customers into behavioural groups
using unsupervised learning, in order to support targeted retention
strategies.

## Dataset

**IBM / Kaggle Telco Customer Churn dataset** — 7,043 customers, 21 attributes
(demographics, account information, subscribed services, and churn label).

- Kaggle listing: https://www.kaggle.com/datasets/blastchar/telco-customer-churn
- Raw CSV mirror used by this project (IBM sample data, identical file):
  `https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv`
- A local copy is included at `data/telco_churn.csv` for reproducibility.

## Project structure

```
churn_project/
├── data/
│   └── telco_churn.csv              # raw dataset
├── code/
│   └── churn_pipeline.py            # full end-to-end pipeline (single script)
├── outputs/                         # generated on each run
│   ├── 01..14_*.png                 # EDA / evaluation / clustering plots
│   ├── cleaned_data_scaled.csv
│   ├── cleaned_data_unscaled.csv
│   ├── model_comparison.csv
│   ├── cluster_profile.csv
│   ├── summary.json
│   └── results_summary.txt          # full console log of a run
├── requirements.txt
└── README.md
```

## How to run

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cd code
python3 churn_pipeline.py
```

Running the script regenerates every plot and metric file inside `outputs/`.
No manual steps or external services are required — the script is fully
self-contained and deterministic (`random_state=42` everywhere).

## Pipeline summary

1. **Preprocessing** — drop `customerID`, impute 11 missing `TotalCharges`
   values with the median, label-encode binary categoricals, one-hot encode
   multi-category categoricals, standardise numeric features.
2. **EDA** — churn distribution, tenure/monthly-charges vs churn, churn rate
   by contract and internet-service type, correlation heatmap.
3. **Supervised models** — Logistic Regression, Naive Bayes, Decision Tree,
   Random Forest (Bagging), Gradient Boosting (Boosting), evaluated with
   Accuracy, Precision, Recall, F1-score, ROC-AUC and confusion matrices on
   an 80/20 stratified train/test split.
4. **Unsupervised segmentation** — K-Means on behavioural/service features,
   k chosen via elbow + silhouette analysis, profiled by churn rate.
5. **PCA** — 2-D projection for cluster visualization.
6. **Business output** — identification of the highest-risk customer
   segment and retention recommendations.

## License / attribution

Dataset originally released by IBM as a sample dataset for the Watson
Analytics community; widely redistributed (e.g. via Kaggle) for churn
analytics education and benchmarking. Used here for academic purposes only.
