"""
Customer Churn Prediction and Segmentation System
===================================================
End-to-end ML pipeline:
  1. Data loading & preprocessing
  2. Exploratory Data Analysis (EDA)
  3. Train/test split
  4. Supervised learning: Logistic Regression, Naive Bayes, Decision Tree,
     Random Forest (Bagging), Gradient Boosting (Boosting)
  5. Model evaluation & comparison, best-model selection
  6. K-Means customer segmentation (with elbow + silhouette method)
  7. PCA for dimensionality reduction / cluster visualization
  8. High-risk segment identification & retention recommendations

Dataset: IBM Telco Customer Churn dataset (public), 7,043 customers, 21 attributes.
Source (mirror used for reproducible download):
https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv
Original source: IBM Sample Data Sets / Kaggle
("Telco Customer Churn" — https://www.kaggle.com/datasets/blastchar/telco-customer-churn)

Run:  python3 churn_pipeline.py
All plots are saved to ../outputs/ and a text summary of every metric is
written to ../outputs/results_summary.txt (also printed to stdout).
"""

import warnings
warnings.filterwarnings("ignore")

import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix, roc_auc_score,
                              roc_curve, classification_report)
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.decomposition import PCA

sns.set_style("whitegrid")
plt.rcParams["figure.dpi"] = 110

DATA_PATH = "../data/telco_churn.csv"
OUT_DIR = "../outputs/"
RANDOM_STATE = 42

log_lines = []
def log(msg=""):
    print(msg)
    log_lines.append(str(msg))

# --------------------------------------------------------------------------
# 1. LOAD DATA
# --------------------------------------------------------------------------
log("=" * 70)
log("STEP 1: LOAD DATA")
log("=" * 70)

df = pd.read_csv(DATA_PATH)
log(f"Raw shape: {df.shape}")
log(f"Columns: {list(df.columns)}")

# --------------------------------------------------------------------------
# 2. DATA PREPROCESSING
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 2: DATA PREPROCESSING")
log("=" * 70)

# 2a. Irrelevant attribute removal — customerID is a unique identifier with
#     no predictive value and must be dropped before modelling.
df.drop(columns=["customerID"], inplace=True)
log("Dropped irrelevant attribute: customerID")

# 2b. Handle missing values.
#     TotalCharges is loaded as object because a small number of new
#     customers (tenure = 0) have blank strings instead of numeric values.
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
n_missing = df["TotalCharges"].isna().sum()
log(f"Missing values found in TotalCharges: {n_missing}")
# Impute with median (robust to skew) rather than dropping rows.
df["TotalCharges"] = df["TotalCharges"].fillna(df["TotalCharges"].median())
log(f"Missing values after imputation: {df.isna().sum().sum()}")

# 2c. Target variable encoding
df["Churn"] = df["Churn"].map({"Yes": 1, "No": 0})
log(f"Churn distribution:\n{df['Churn'].value_counts()}")

# 2d. Encode categorical attributes
binary_cols = ["gender", "Partner", "Dependents", "PhoneService", "PaperlessBilling"]
le = LabelEncoder()
for col in binary_cols:
    df[col] = le.fit_transform(df[col])
log(f"Label-encoded binary columns: {binary_cols}")

multi_cat_cols = ["MultipleLines", "InternetService", "OnlineSecurity", "OnlineBackup",
                   "DeviceProtection", "TechSupport", "StreamingTV", "StreamingMovies",
                   "Contract", "PaymentMethod"]
df = pd.get_dummies(df, columns=multi_cat_cols, drop_first=True)
bool_cols = df.select_dtypes(include="bool").columns
df[bool_cols] = df[bool_cols].astype(int)
log(f"One-hot encoded multi-category columns: {multi_cat_cols}")
log(f"Shape after encoding: {df.shape}")

# 2e. Feature scaling — numeric features are on very different scales
#     (tenure in months, MonthlyCharges/TotalCharges in currency), so we
#     standardise them for distance/gradient-based algorithms (LR, SVM, KMeans, PCA).
numeric_cols = ["tenure", "MonthlyCharges", "TotalCharges", "SeniorCitizen"]
scaler = StandardScaler()
df_scaled = df.copy()
df_scaled[numeric_cols] = scaler.fit_transform(df_scaled[numeric_cols])
log(f"Scaled numeric columns: {numeric_cols}")

df.to_csv(OUT_DIR + "cleaned_data_unscaled.csv", index=False)
df_scaled.to_csv(OUT_DIR + "cleaned_data_scaled.csv", index=False)

# --------------------------------------------------------------------------
# 3. EXPLORATORY DATA ANALYSIS
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 3: EXPLORATORY DATA ANALYSIS")
log("=" * 70)

# 3a. Churn class balance
plt.figure(figsize=(5, 4))
counts = df["Churn"].value_counts()
plt.bar(["No Churn", "Churn"], counts.values, color=["#4C72B0", "#DD8452"])
for i, v in enumerate(counts.values):
    plt.text(i, v + 30, f"{v} ({v/len(df)*100:.1f}%)", ha="center")
plt.title("Customer Churn Distribution")
plt.ylabel("Number of customers")
plt.tight_layout()
plt.savefig(OUT_DIR + "01_churn_distribution.png")
plt.close()
churn_rate = df["Churn"].mean() * 100
log(f"Overall churn rate: {churn_rate:.2f}%  (class imbalance present)")

# 3b. Tenure distribution by churn
plt.figure(figsize=(6, 4))
sns.histplot(data=df, x="tenure", hue="Churn", bins=30, kde=True, palette=["#4C72B0", "#DD8452"])
plt.title("Tenure Distribution by Churn Status")
plt.xlabel("Tenure (months)")
plt.tight_layout()
plt.savefig(OUT_DIR + "02_tenure_by_churn.png")
plt.close()

# 3c. Monthly charges by churn
plt.figure(figsize=(6, 4))
sns.boxplot(data=df, x="Churn", y="MonthlyCharges", palette=["#4C72B0", "#DD8452"])
plt.xticks([0, 1], ["No Churn", "Churn"])
plt.title("Monthly Charges by Churn Status")
plt.tight_layout()
plt.savefig(OUT_DIR + "03_monthlycharges_by_churn.png")
plt.close()

# 3d. Contract type vs churn rate
contract_cols = [c for c in df.columns if c.startswith("Contract_")]
orig_contract = pd.read_csv(DATA_PATH)["Contract"]
tmp = pd.DataFrame({"Contract": orig_contract, "Churn": df["Churn"]})
contract_churn = tmp.groupby("Contract")["Churn"].mean().sort_values(ascending=False) * 100
plt.figure(figsize=(6, 4))
contract_churn.plot(kind="bar", color="#C44E52")
plt.ylabel("Churn rate (%)")
plt.title("Churn Rate by Contract Type")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT_DIR + "04_churn_by_contract.png")
plt.close()
log(f"Churn rate by contract type:\n{contract_churn}")

# 3e. Correlation heatmap of numeric features
plt.figure(figsize=(6, 5))
corr = df[["tenure", "MonthlyCharges", "TotalCharges", "SeniorCitizen", "Churn"]].corr()
sns.heatmap(corr, annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap (Numeric Features)")
plt.tight_layout()
plt.savefig(OUT_DIR + "05_correlation_heatmap.png")
plt.close()

# 3f. Internet service vs churn
orig_internet = pd.read_csv(DATA_PATH)["InternetService"]
tmp2 = pd.DataFrame({"InternetService": orig_internet, "Churn": df["Churn"]})
internet_churn = tmp2.groupby("InternetService")["Churn"].mean().sort_values(ascending=False) * 100
plt.figure(figsize=(6, 4))
internet_churn.plot(kind="bar", color="#55A868")
plt.ylabel("Churn rate (%)")
plt.title("Churn Rate by Internet Service Type")
plt.xticks(rotation=20)
plt.tight_layout()
plt.savefig(OUT_DIR + "06_churn_by_internet.png")
plt.close()

log("Saved 6 EDA plots to outputs/")

# --------------------------------------------------------------------------
# 4. TRAIN / TEST SPLIT
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 4: TRAIN / TEST SPLIT")
log("=" * 70)

X = df_scaled.drop(columns=["Churn"])
y = df_scaled["Churn"]
feature_names = X.columns.tolist()

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=RANDOM_STATE, stratify=y
)
log(f"Training set: {X_train.shape}, Test set: {X_test.shape}")
log(f"Train churn rate: {y_train.mean()*100:.2f}% | Test churn rate: {y_test.mean()*100:.2f}%")

# --------------------------------------------------------------------------
# 5. SUPERVISED LEARNING MODELS
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 5: MODEL TRAINING (5 supervised algorithms)")
log("=" * 70)

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=RANDOM_STATE),
    "Naive Bayes": GaussianNB(),
    "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=RANDOM_STATE),
    "Random Forest (Bagging)": RandomForestClassifier(
        n_estimators=200, max_depth=8, random_state=RANDOM_STATE),
    "Gradient Boosting (Boosting)": GradientBoostingClassifier(
        n_estimators=150, max_depth=3, random_state=RANDOM_STATE),
}

results = {}
roc_data = {}
fitted_models = {}

for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    prec = precision_score(y_test, y_pred)
    rec = recall_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)
    cm = confusion_matrix(y_test, y_pred)

    results[name] = {"Accuracy": acc, "Precision": prec, "Recall": rec,
                      "F1-score": f1, "ROC-AUC": auc, "ConfusionMatrix": cm.tolist()}
    roc_data[name] = roc_curve(y_test, y_proba)
    fitted_models[name] = model

    log(f"\n--- {name} ---")
    log(f"Accuracy={acc:.4f}  Precision={prec:.4f}  Recall={rec:.4f}  F1={f1:.4f}  ROC-AUC={auc:.4f}")
    log(f"Confusion Matrix:\n{cm}")

    # Individual confusion matrix plot
    plt.figure(figsize=(4, 3.5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["No Churn", "Churn"], yticklabels=["No Churn", "Churn"])
    plt.title(f"Confusion Matrix: {name}")
    plt.ylabel("Actual")
    plt.xlabel("Predicted")
    plt.tight_layout()
    fname = name.lower().replace(" ", "_").replace("(", "").replace(")", "")
    plt.savefig(OUT_DIR + f"07_cm_{fname}.png")
    plt.close()

results_df = pd.DataFrame(results).T[["Accuracy", "Precision", "Recall", "F1-score", "ROC-AUC"]]
results_df = results_df.sort_values("F1-score", ascending=False)
log("\n" + "=" * 70)
log("MODEL COMPARISON TABLE (sorted by F1-score)")
log("=" * 70)
log(results_df.round(4).to_string())
results_df.round(4).to_csv(OUT_DIR + "model_comparison.csv")

best_model_name = results_df.index[0]
log(f"\nBEST MODEL (by F1-score, appropriate for imbalanced churn classes): {best_model_name}")

# --------------------------------------------------------------------------
# 6. MODEL COMPARISON VISUALIZATIONS
# --------------------------------------------------------------------------
plt.figure(figsize=(9, 5))
results_df[["Accuracy", "Precision", "Recall", "F1-score"]].plot(kind="bar", figsize=(9, 5))
plt.title("Model Performance Comparison")
plt.ylabel("Score")
plt.ylim(0, 1)
plt.xticks(rotation=20)
plt.legend(loc="lower right")
plt.tight_layout()
plt.savefig(OUT_DIR + "08_model_comparison_bar.png")
plt.close()

plt.figure(figsize=(6, 5))
for name, (fpr, tpr, _) in roc_data.items():
    plt.plot(fpr, tpr, label=f"{name} (AUC={results[name]['ROC-AUC']:.3f})")
plt.plot([0, 1], [0, 1], "k--", alpha=0.4)
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curves — All Models")
plt.legend(loc="lower right", fontsize=8)
plt.tight_layout()
plt.savefig(OUT_DIR + "09_roc_curves.png")
plt.close()

# Feature importance from best tree-based model (Random Forest) for interpretability
rf_model = fitted_models["Random Forest (Bagging)"]
importances = pd.Series(rf_model.feature_importances_, index=feature_names).sort_values(ascending=False).head(12)
plt.figure(figsize=(7, 5))
importances.sort_values().plot(kind="barh", color="#4C72B0")
plt.title("Top 12 Feature Importances (Random Forest)")
plt.tight_layout()
plt.savefig(OUT_DIR + "10_feature_importance.png")
plt.close()

log("Saved model comparison bar chart, ROC curves, and feature importance plot.")

# --------------------------------------------------------------------------
# 7. K-MEANS CUSTOMER SEGMENTATION
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 7: K-MEANS CUSTOMER SEGMENTATION")
log("=" * 70)

# Behavioural / service-related attributes chosen for segmentation
cluster_features = ["tenure", "MonthlyCharges", "TotalCharges"]
service_flags = ["PhoneService", "PaperlessBilling"]
extra_service_cols = [c for c in df.columns if any(
    c.startswith(p) for p in ["InternetService_", "Contract_", "OnlineSecurity_",
                               "TechSupport_", "StreamingTV_", "StreamingMovies_"])]
cluster_cols = cluster_features + service_flags + extra_service_cols
log(f"Features used for clustering ({len(cluster_cols)}): {cluster_cols}")

X_cluster = df_scaled[cluster_cols]

# 7a. Elbow method + silhouette score to choose k
inertias, sil_scores = [], []
k_range = range(2, 9)
for k in k_range:
    km = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
    labels = km.fit_predict(X_cluster)
    inertias.append(km.inertia_)
    sil_scores.append(silhouette_score(X_cluster, labels))

fig, ax1 = plt.subplots(figsize=(7, 4.5))
ax1.plot(list(k_range), inertias, "o-", color="#4C72B0", label="Inertia (Elbow)")
ax1.set_xlabel("Number of clusters (k)")
ax1.set_ylabel("Inertia", color="#4C72B0")
ax2 = ax1.twinx()
ax2.plot(list(k_range), sil_scores, "s-", color="#DD8452", label="Silhouette score")
ax2.set_ylabel("Silhouette score", color="#DD8452")
plt.title("K-Means: Elbow Method & Silhouette Score")
fig.tight_layout()
plt.savefig(OUT_DIR + "11_kmeans_elbow_silhouette.png")
plt.close()

log(f"Inertia by k: {dict(zip(k_range, [round(i,1) for i in inertias]))}")
log(f"Silhouette by k: {dict(zip(k_range, [round(s,4) for s in sil_scores]))}")

best_k = list(k_range)[int(np.argmax(sil_scores))]
log(f"Chosen k (highest silhouette score): {best_k}")

kmeans_final = KMeans(n_clusters=best_k, random_state=RANDOM_STATE, n_init=10)
cluster_labels = kmeans_final.fit_predict(X_cluster)
df["Cluster"] = cluster_labels
df_scaled["Cluster"] = cluster_labels

# 7b. Cluster profiling (means in original/unscaled units)
profile_cols = ["tenure", "MonthlyCharges", "TotalCharges", "Churn"]
cluster_profile = df.groupby("Cluster")[profile_cols].mean()
cluster_profile["Count"] = df.groupby("Cluster").size()
cluster_profile["ChurnRate(%)"] = cluster_profile["Churn"] * 100
log("\nCluster profile (mean values, unscaled):")
log(cluster_profile.round(2).to_string())
cluster_profile.round(2).to_csv(OUT_DIR + "cluster_profile.csv")

# --------------------------------------------------------------------------
# 8. PCA FOR DIMENSIONALITY REDUCTION / VISUALIZATION
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 8: PCA FOR CLUSTER VISUALIZATION")
log("=" * 70)

pca = PCA(n_components=2, random_state=RANDOM_STATE)
X_pca = pca.fit_transform(X_cluster)
log(f"Explained variance ratio (PC1, PC2): {pca.explained_variance_ratio_}")
log(f"Total variance captured by 2 components: {pca.explained_variance_ratio_.sum()*100:.2f}%")

plt.figure(figsize=(7, 5.5))
scatter = plt.scatter(X_pca[:, 0], X_pca[:, 1], c=cluster_labels, cmap="tab10", alpha=0.6, s=15)
centers_pca = pca.transform(kmeans_final.cluster_centers_)
plt.scatter(centers_pca[:, 0], centers_pca[:, 1], c="black", marker="X", s=200, label="Centroids")
plt.xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)")
plt.ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)")
plt.title(f"Customer Segments via K-Means (k={best_k}) — PCA Projection")
plt.legend()
plt.colorbar(scatter, label="Cluster")
plt.tight_layout()
plt.savefig(OUT_DIR + "12_pca_clusters.png")
plt.close()

# PCA clusters colored by churn for interpretability
plt.figure(figsize=(7, 5.5))
colors = df["Churn"].map({0: "#4C72B0", 1: "#DD8452"})
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=colors, alpha=0.5, s=15)
plt.xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)")
plt.ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)")
plt.title("PCA Projection Colored by Actual Churn")
handles = [plt.Line2D([0], [0], marker="o", color="w", markerfacecolor=c, markersize=8)
           for c in ["#4C72B0", "#DD8452"]]
plt.legend(handles, ["No Churn", "Churn"])
plt.tight_layout()
plt.savefig(OUT_DIR + "13_pca_churn.png")
plt.close()

log("Saved PCA cluster visualizations.")

# --------------------------------------------------------------------------
# 9. HIGH-RISK SEGMENT IDENTIFICATION
# --------------------------------------------------------------------------
log("\n" + "=" * 70)
log("STEP 9: HIGH-RISK SEGMENT IDENTIFICATION")
log("=" * 70)

high_risk_cluster = cluster_profile["ChurnRate(%)"].idxmax()
log(f"Highest-risk cluster: Cluster {high_risk_cluster} "
    f"(churn rate {cluster_profile.loc[high_risk_cluster, 'ChurnRate(%)']:.2f}%, "
    f"{int(cluster_profile.loc[high_risk_cluster, 'Count'])} customers)")

plt.figure(figsize=(6, 4))
cluster_profile["ChurnRate(%)"].plot(kind="bar", color="#C44E52")
plt.ylabel("Churn rate (%)")
plt.xlabel("Cluster")
plt.title("Churn Rate by Customer Segment")
plt.tight_layout()
plt.savefig(OUT_DIR + "14_churn_rate_by_cluster.png")
plt.close()

# --------------------------------------------------------------------------
# SAVE SUMMARY
# --------------------------------------------------------------------------
summary = {
    "dataset_shape_raw": [7043, 21],
    "churn_rate_pct": round(churn_rate, 2),
    "best_classification_model": best_model_name,
    "best_model_metrics": {k: round(v, 4) for k, v in results[best_model_name].items() if k != "ConfusionMatrix"},
    "chosen_k": int(best_k),
    "high_risk_cluster": int(high_risk_cluster),
    "high_risk_cluster_churn_rate_pct": round(cluster_profile.loc[high_risk_cluster, "ChurnRate(%)"], 2),
}
with open(OUT_DIR + "summary.json", "w") as f:
    json.dump(summary, f, indent=2)

with open(OUT_DIR + "results_summary.txt", "w") as f:
    f.write("\n".join(log_lines))

log("\n" + "=" * 70)
log("PIPELINE COMPLETE. All outputs saved to outputs/")
log("=" * 70)
