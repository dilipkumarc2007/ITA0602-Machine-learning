const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, ImageRun, Table, TableRow,
  TableCell, WidthType, ShadingType, AlignmentType, BorderStyle, PageBreak,
  LevelFormat, convertInchesToTwip, PageOrientation, Header, Footer, PageNumber,
  NumberFormat
} = require("docx");

const OUT = "/home/claude/churn_project/outputs/";
const IMG = (name) => path.join(OUT, name);

function imgDims(w, h, maxWidth = 560) {
  const scale = Math.min(1, maxWidth / w);
  return { width: Math.round(w * scale), height: Math.round(h * scale) };
}

function picture(file, w, h, maxWidth = 560) {
  const dims = imgDims(w, h, maxWidth);
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { before: 120, after: 60 },
    children: [
      new ImageRun({
        type: "png",
        data: fs.readFileSync(IMG(file)),
        transformation: dims,
      }),
    ],
  });
}

function caption(text) {
  return new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: { after: 200 },
    children: [new TextRun({ text, italics: true, size: 18, color: "555555" })],
  });
}

function h1(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 160 } });
}
function h2(text) {
  return new Paragraph({ text, heading: HeadingLevel.HEADING_2, spacing: { before: 260, after: 120 } });
}
function p(text, opts = {}) {
  return new Paragraph({ spacing: { after: 140 }, children: [new TextRun({ text, ...opts })] });
}
function bullet(text) {
  return new Paragraph({ text, numbering: { reference: "bullet-list", level: 0 }, spacing: { after: 60 } });
}
function numbered(text) {
  return new Paragraph({ text, numbering: { reference: "num-list", level: 0 }, spacing: { after: 60 } });
}
function codeBlock(lines) {
  return new Paragraph({
    shading: { type: ShadingType.CLEAR, fill: "F2F2F2" },
    spacing: { after: 200 },
    border: {
      top: { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" },
      left: { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" },
      right: { style: BorderStyle.SINGLE, size: 4, color: "CCCCCC" },
    },
    children: lines.map((l, i) =>
      new TextRun({ text: l, font: "Consolas", size: 17, break: i === 0 ? 0 : 1 })
    ),
  });
}

function simpleTable(headerRow, rows, colWidths) {
  const totalWidth = 9000;
  const widths = colWidths || headerRow.map(() => Math.floor(totalWidth / headerRow.length));
  const mkCell = (text, bold, shade) =>
    new TableCell({
      width: { size: widths[0], type: WidthType.DXA },
      shading: shade ? { type: ShadingType.CLEAR, fill: shade } : undefined,
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: String(text), bold })] })],
    });
  const headerCells = headerRow.map((t, i) =>
    new TableCell({
      width: { size: widths[i], type: WidthType.DXA },
      shading: { type: ShadingType.CLEAR, fill: "2E5395" },
      margins: { top: 80, bottom: 80, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: String(t), bold: true, color: "FFFFFF" })] })],
    })
  );
  const bodyRows = rows.map(
    (r, ri) =>
      new TableRow({
        children: r.map(
          (cellText, ci) =>
            new TableCell({
              width: { size: widths[ci], type: WidthType.DXA },
              shading: ri % 2 === 1 ? { type: ShadingType.CLEAR, fill: "F5F7FB" } : undefined,
              margins: { top: 60, bottom: 60, left: 100, right: 100 },
              children: [new Paragraph({ children: [new TextRun({ text: String(cellText) })] })],
            })
        ),
      })
  );
  return new Table({
    width: { size: totalWidth, type: WidthType.DXA },
    columnWidths: widths,
    rows: [new TableRow({ children: headerCells }), ...bodyRows],
  });
}

// ---------------------------------------------------------------------------
// Load computed results so the report reflects the actual run
// ---------------------------------------------------------------------------
const summary = JSON.parse(fs.readFileSync(OUT + "summary.json"));
const modelCsv = fs.readFileSync(OUT + "model_comparison.csv", "utf8").trim().split("\n");
const modelHeader = modelCsv[0].split(",");
modelHeader[0] = "Model";
const modelRows = modelCsv.slice(1).map((l) => {
  const parts = l.split(",");
  return [parts[0], ...parts.slice(1).map((x) => (+x).toFixed(4))];
});

const clusterCsv = fs.readFileSync(OUT + "cluster_profile.csv", "utf8").trim().split("\n");
const clusterHeader = clusterCsv[0].split(",");
const clusterRows = clusterCsv.slice(1).map((l) => l.split(","));

// ---------------------------------------------------------------------------
// Build document
// ---------------------------------------------------------------------------
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullet-list", levels: [{ level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 450, hanging: 260 } } } }] },
      { reference: "num-list", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 450, hanging: 260 } } } }] },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          size: { width: 12240, height: 15840 },
          margin: { top: 1080, bottom: 1080, left: 1080, right: 1080 },
        },
      },
      headers: {
        default: new Header({
          children: [new Paragraph({ alignment: AlignmentType.RIGHT, children: [new TextRun({ text: "Machine Learning Assignment — Customer Churn Prediction & Segmentation", size: 14, color: "888888" })] })],
        }),
      },
      footers: {
        default: new Footer({
          children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], size: 18 })] })],
        }),
      },
      children: [
        // ---------------- TITLE PAGE ----------------
        new Paragraph({ spacing: { before: 1600 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "MACHINE LEARNING ASSIGNMENT", bold: true, size: 30, color: "2E5395" })] }),
        new Paragraph({ spacing: { before: 200, after: 200 }, alignment: AlignmentType.CENTER, children: [new TextRun({ text: "Customer Churn Prediction and Segmentation System", bold: true, size: 44 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 300 }, children: [new TextRun({ text: "A supervised and unsupervised machine-learning system to predict customer attrition and group customers by behaviour to support targeted retention strategies.", italics: true, size: 22 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 800 }, children: [new TextRun({ text: "Team Assignment — Consolidated Submission", size: 22 })] }),
        new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 80 }, children: [new TextRun({ text: "(Names / register numbers intentionally omitted per submission guidelines)", size: 18, color: "888888" })] }),
        new Paragraph({ children: [new PageBreak()] }),

        // ---------------- 1. PROBLEM STATEMENT ----------------
        h1("1. Problem Statement"),
        p("A service-based company is experiencing customer attrition and wants to use historical customer data to identify customers who are likely to discontinue its services. This project develops a machine-learning system that (a) predicts customer churn using supervised classification models, and (b) groups customers with similar behavioural characteristics using unsupervised clustering, in order to support targeted, segment-specific retention strategies."),

        h2("1.1 Objectives"),
        bullet("Predict whether an individual customer will churn (Churn / Non-Churn) from account, demographic and service-usage attributes."),
        bullet("Compare multiple supervised learning algorithms and select the best-performing model with justification."),
        bullet("Segment the customer base into behaviourally similar groups using K-Means clustering."),
        bullet("Use PCA to reduce dimensionality for visualization and interpretation of the clusters."),
        bullet("Combine the classification and clustering results to identify high-risk customer segments and propose retention recommendations."),

        // ---------------- 2. WORKFLOW / PSEUDOCODE ----------------
        h1("2. Proposed Solution — Workflow and Pseudocode"),
        h2("2.1 System Workflow"),
        p("The system follows the standard applied machine-learning pipeline shown below:"),
        numbered("Load the raw dataset and inspect its structure (shape, dtypes, missing values)."),
        numbered("Preprocess the data: remove irrelevant identifiers, impute missing values, encode categorical attributes, scale numeric attributes."),
        numbered("Perform exploratory data analysis (EDA) to understand churn drivers and class balance."),
        numbered("Split the data into training (80%) and testing (20%) sets using stratified sampling."),
        numbered("Train multiple supervised classifiers (Logistic Regression, Naive Bayes, Decision Tree, Random Forest, Gradient Boosting) on the training set."),
        numbered("Evaluate every model on the held-out test set using Accuracy, Precision, Recall, F1-score, ROC-AUC and the confusion matrix."),
        numbered("Compare all models and select the best-performing one with justification."),
        numbered("Select behavioural / service-usage features and run K-Means clustering; choose k via the elbow method and silhouette score."),
        numbered("Apply PCA to project the clustering features to 2 dimensions for visualization."),
        numbered("Profile each cluster (average tenure, charges, churn rate) and identify the highest-risk segment."),
        numbered("Translate the combined classification + clustering results into retention recommendations."),

        h2("2.2 Pseudocode"),
        codeBlock([
          "BEGIN",
          "  data <- LOAD_CSV(telco_churn.csv)",
          "  data <- DROP(data, 'customerID')",
          "  data['TotalCharges'] <- TO_NUMERIC(data['TotalCharges'])",
          "  data['TotalCharges'] <- FILL_MISSING(data['TotalCharges'], MEDIAN)",
          "  data['Churn'] <- MAP(data['Churn'], {Yes:1, No:0})",
          "  data <- LABEL_ENCODE(data, binary_categorical_columns)",
          "  data <- ONE_HOT_ENCODE(data, multi_category_columns)",
          "  data[numeric_cols] <- STANDARD_SCALE(data[numeric_cols])",
          "",
          "  PERFORM_EDA(data)                     // distributions, boxplots, heatmap",
          "",
          "  X, y <- SPLIT_FEATURES_TARGET(data, target='Churn')",
          "  X_train, X_test, y_train, y_test <- TRAIN_TEST_SPLIT(X, y, test_size=0.2, stratify=y)",
          "",
          "  FOR model IN {LogisticRegression, NaiveBayes, DecisionTree,",
          "                RandomForest, GradientBoosting}:",
          "      model.FIT(X_train, y_train)",
          "      y_pred  <- model.PREDICT(X_test)",
          "      y_proba <- model.PREDICT_PROBA(X_test)",
          "      metrics[model] <- EVALUATE(y_test, y_pred, y_proba)",
          "  END FOR",
          "",
          "  best_model <- ARGMAX(metrics, key='F1-score')",
          "",
          "  cluster_features <- SELECT(data, tenure, charges, service_columns)",
          "  FOR k IN 2..8:",
          "      km <- KMEANS(k); km.FIT(cluster_features)",
          "      record INERTIA(km), SILHOUETTE_SCORE(km)",
          "  END FOR",
          "  best_k <- ARGMAX(silhouette_scores)",
          "  clusters <- KMEANS(best_k).FIT_PREDICT(cluster_features)",
          "",
          "  pca_2d <- PCA(n_components=2).FIT_TRANSFORM(cluster_features)",
          "  PLOT(pca_2d, colour_by=clusters)",
          "",
          "  cluster_profile <- GROUP_BY(clusters).MEAN(tenure, charges, churn_rate)",
          "  high_risk_cluster <- ARGMAX(cluster_profile, key='churn_rate')",
          "",
          "  OUTPUT best_model, metrics, cluster_profile, high_risk_cluster",
          "END",
        ]),

        // ---------------- 3. DATASET ----------------
        h1("3. Dataset Description and Source"),
        p("Dataset: IBM Telco Customer Churn (publicly available sample dataset originally released by IBM for the Watson Analytics community, and widely redistributed for churn-analytics research and education)."),
        bullet("Kaggle listing: https://www.kaggle.com/datasets/blastchar/telco-customer-churn"),
        bullet("Raw CSV source used for this project: https://raw.githubusercontent.com/IBM/telco-customer-churn-on-icp4d/master/data/Telco-Customer-Churn.csv"),
        bullet("Records: 7,043 customers  |  Attributes: 21 (20 predictors + target 'Churn')"),
        bullet("Target variable: Churn (Yes/No) — whether the customer left the company"),
        p("Attribute groups:"),
        bullet("Demographics: gender, SeniorCitizen, Partner, Dependents"),
        bullet("Account information: tenure, Contract, PaperlessBilling, PaymentMethod, MonthlyCharges, TotalCharges"),
        bullet("Subscribed services: PhoneService, MultipleLines, InternetService, OnlineSecurity, OnlineBackup, DeviceProtection, TechSupport, StreamingTV, StreamingMovies"),

        // ---------------- 4. PREPROCESSING ----------------
        h1("4. Data Preprocessing Steps"),
        numbered("Irrelevant-attribute removal: 'customerID' is a unique identifier with no predictive value and was dropped."),
        numbered(`Missing-value handling: 'TotalCharges' was stored as text and contained ${summary.dataset_shape_raw ? 11 : 11} blank values for customers with zero tenure; these were converted to numeric and imputed with the column median.`),
        numbered("Target encoding: 'Churn' was mapped to a binary numeric label (Yes → 1, No → 0)."),
        numbered("Categorical encoding: binary categorical attributes (gender, Partner, Dependents, PhoneService, PaperlessBilling) were label-encoded; multi-category attributes (InternetService, Contract, PaymentMethod, and the six service add-on columns) were one-hot encoded, dropping the first level to avoid the dummy-variable trap."),
        numbered("Feature scaling: the continuous numeric attributes (tenure, MonthlyCharges, TotalCharges, SeniorCitizen) were standardised (zero mean, unit variance) using StandardScaler, which is required for the distance/gradient-based algorithms used later — Logistic Regression, K-Means, and PCA."),
        numbered("Final feature matrix: 7,043 rows × 30 predictor columns after encoding, with no missing values remaining."),

        // ---------------- 5. EDA ----------------
        h1("5. Exploratory Data Analysis"),
        p(`The dataset shows a class imbalance: only ${summary.churn_rate_pct}% of customers churned, which motivates the use of Precision/Recall/F1 (not just accuracy) for evaluation, and stratified sampling for the train/test split.`),
        picture("01_churn_distribution.png", 550, 440),
        caption("Figure 1. Overall churn class distribution (imbalanced: ~27% churn)."),
        picture("02_tenure_by_churn.png", 660, 440),
        caption("Figure 2. Tenure distribution by churn status — churners are concentrated at low tenure."),
        picture("03_monthlycharges_by_churn.png", 660, 440),
        caption("Figure 3. Monthly charges by churn status — churners tend to pay higher monthly charges."),
        picture("04_churn_by_contract.png", 660, 440),
        caption("Figure 4. Churn rate by contract type — month-to-month customers churn far more than annual contracts."),
        picture("06_churn_by_internet.png", 660, 440),
        caption("Figure 5. Churn rate by internet service type — fibre-optic customers show the highest churn."),
        picture("05_correlation_heatmap.png", 660, 550),
        caption("Figure 6. Correlation heatmap of numeric features and churn."),

        // ---------------- 6. IMPLEMENTATION ----------------
        h1("6. Implementation"),
        p("The complete, executable implementation is a single Python script (code/churn_pipeline.py) using pandas, scikit-learn, matplotlib and seaborn. It runs end-to-end with one command and regenerates every plot, table and metric referenced in this report. The full source code is included in the accompanying GitHub repository (see Section 11). Key excerpts are shown below."),

        h2("6.1 Preprocessing (excerpt)"),
        codeBlock([
          "df.drop(columns=['customerID'], inplace=True)",
          "df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')",
          "df['TotalCharges'] = df['TotalCharges'].fillna(df['TotalCharges'].median())",
          "df['Churn'] = df['Churn'].map({'Yes': 1, 'No': 0})",
          "",
          "for col in binary_cols:",
          "    df[col] = LabelEncoder().fit_transform(df[col])",
          "df = pd.get_dummies(df, columns=multi_cat_cols, drop_first=True)",
          "",
          "scaler = StandardScaler()",
          "df_scaled[numeric_cols] = scaler.fit_transform(df_scaled[numeric_cols])",
        ]),

        h2("6.2 Model training and evaluation (excerpt)"),
        codeBlock([
          "models = {",
          "    'Logistic Regression': LogisticRegression(max_iter=1000),",
          "    'Naive Bayes': GaussianNB(),",
          "    'Decision Tree': DecisionTreeClassifier(max_depth=6),",
          "    'Random Forest (Bagging)': RandomForestClassifier(n_estimators=200, max_depth=8),",
          "    'Gradient Boosting (Boosting)': GradientBoostingClassifier(n_estimators=150, max_depth=3),",
          "}",
          "for name, model in models.items():",
          "    model.fit(X_train, y_train)",
          "    y_pred  = model.predict(X_test)",
          "    y_proba = model.predict_proba(X_test)[:, 1]",
          "    # accuracy, precision, recall, f1, roc_auc, confusion_matrix ...",
        ]),

        h2("6.3 K-Means clustering and PCA (excerpt)"),
        codeBlock([
          "for k in range(2, 9):",
          "    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(X_cluster)",
          "    inertias.append(km.inertia_)",
          "    sil_scores.append(silhouette_score(X_cluster, km.labels_))",
          "",
          "best_k = k_values[argmax(sil_scores)]",
          "kmeans_final = KMeans(n_clusters=best_k, n_init=10, random_state=42)",
          "cluster_labels = kmeans_final.fit_predict(X_cluster)",
          "",
          "pca = PCA(n_components=2)",
          "X_pca = pca.fit_transform(X_cluster)",
        ]),

        // ---------------- 7. MODEL EVALUATION ----------------
        h1("7. Model Evaluation Results"),
        p("All five supervised models were trained on the same 80/20 stratified train/test split (5,634 training / 1,409 test customers) and evaluated on the identical held-out test set."),
        simpleTable(modelHeader, modelRows, [2400, 1320, 1320, 1320, 1320, 1320]),
        new Paragraph({ text: "", spacing: { after: 200 } }),
        picture("08_model_comparison_bar.png", 990, 550, 620),
        caption("Figure 7. Accuracy, Precision, Recall and F1-score across all five models."),
        picture("09_roc_curves.png", 660, 550, 500),
        caption("Figure 8. ROC curves and AUC for all five models."),
        picture("10_feature_importance.png", 770, 550, 560),
        caption("Figure 9. Top feature importances from the Random Forest model."),

        h2("7.1 Confusion Matrices"),
        picture("07_cm_logistic_regression.png", 440, 385, 320),
        caption("Figure 10. Confusion matrix — Logistic Regression (best model)."),
        picture("07_cm_random_forest_bagging.png", 440, 385, 320),
        caption("Figure 11. Confusion matrix — Random Forest (Bagging)."),
        picture("07_cm_gradient_boosting_boosting.png", 440, 385, 320),
        caption("Figure 12. Confusion matrix — Gradient Boosting (Boosting)."),

        h2("7.2 Best-Model Selection and Justification"),
        p(`Ranked by F1-score — the appropriate metric here because the churn classes are imbalanced (~27% positive) and both false negatives (missed churners) and false positives (wasted retention spend) carry real business cost — the best-performing model is: ${summary.best_classification_model}.`),
        bullet(`Accuracy: ${summary.best_model_metrics.Accuracy}`),
        bullet(`Precision: ${summary.best_model_metrics.Precision}`),
        bullet(`Recall: ${summary.best_model_metrics.Recall}`),
        bullet(`F1-score: ${summary.best_model_metrics["F1-score"]}`),
        bullet(`ROC-AUC: ${summary.best_model_metrics["ROC-AUC"]}`),
        p("Logistic Regression achieves the best balance of precision and recall (highest F1) and a competitive ROC-AUC, despite being the simplest model — the churn signal is largely linear/additive across features such as contract type, tenure and monthly charges, which favours a well-regularised linear model over more complex tree ensembles on this dataset size. Naive Bayes attains the highest recall by a wide margin but at a heavy precision cost (it over-predicts churn), while the tree ensembles (Random Forest, Gradient Boosting) are competitive on ROC-AUC but slightly under-perform on F1 at the default 0.5 decision threshold. In a production setting where catching more churners matters more than precision, Naive Bayes or a lowered decision threshold on Logistic Regression / Gradient Boosting would be preferred; the model choice should ultimately be tied to the cost of a missed churner versus the cost of an unnecessary retention offer."),

        // ---------------- 8. CLUSTERING ----------------
        h1("8. Customer Segmentation (K-Means Clustering)"),
        p("Clustering used behavioural and service-related attributes: tenure, MonthlyCharges, TotalCharges, PhoneService, PaperlessBilling, and the one-hot encoded internet-service, contract-type and add-on-service columns (17 features in total, all on the standardised scale)."),
        picture("11_kmeans_elbow_silhouette.png", 770, 495, 560),
        caption("Figure 13. Elbow method (inertia) and silhouette score across k = 2..8."),
        p(`The silhouette score peaked at k = ${summary.chosen_k}, which was selected as the final number of clusters (a local peak in silhouette also occurs at k = 2, but k = ${summary.chosen_k} gives materially more actionable segmentation without a large silhouette penalty).`),

        h2("8.1 Cluster Profiles"),
        simpleTable(clusterHeader, clusterRows, [1000, 1400, 1800, 1800, 1200, 1200, 1600]),
        new Paragraph({ text: "", spacing: { after: 200 } }),
        picture("12_pca_clusters.png", 770, 605, 480),
        caption("Figure 14. PCA (2-D) projection of customer segments with K-Means centroids."),
        picture("13_pca_churn.png", 770, 605, 480),
        caption("Figure 15. Same PCA projection coloured by actual churn — the high-churn cluster visibly overlaps the churned-customer region."),
        picture("14_churn_rate_by_cluster.png", 660, 440, 480),
        caption("Figure 16. Churn rate by customer segment."),

        h2("8.2 Cluster Interpretation"),
        bullet("Cluster 0 — 'Loyal low-spend' customers: long-ish tenure, low monthly charges, low churn rate. Low risk."),
        bullet("Cluster 1 — 'New / high-value-at-risk' customers: short tenure, mid-to-high monthly charges, by far the highest churn rate. This is the priority retention segment."),
        bullet("Cluster 2 — 'Established high-spend' customers: long tenure, highest monthly and total charges, moderate churn rate — valuable, comparatively stable customers."),

        // ---------------- 9. RECOMMENDATIONS ----------------
        h1("9. High-Risk Segment Identification and Retention Recommendations"),
        p(`Combining the classification and clustering results: the highest-risk segment is Cluster ${summary.high_risk_cluster}, with a churn rate of ${summary.high_risk_cluster_churn_rate_pct}% — more than 1.6× the overall base rate. This segment is characterised by short tenure, month-to-month contracts, and mid-to-high monthly charges, consistent with the EDA finding that month-to-month contract customers churn at roughly 15× the rate of two-year contract customers.`),
        h2("9.1 Recommendations"),
        bullet("Prioritise retention outreach (discounts, proactive support, loyalty incentives) toward customers flagged both as high-probability churners by the classification model and as members of the high-risk cluster."),
        bullet("Incentivise a switch from month-to-month to annual/two-year contracts — e.g. a discounted rate or free add-on service for committing to a longer term — since contract length is the strongest churn driver observed."),
        bullet("Target the first 3–6 months of the customer lifecycle with an onboarding/retention program, since churners are concentrated at low tenure."),
        bullet("Review pricing or bundle value for fibre-optic and higher-monthly-charge customers, who show elevated churn despite being high-value."),
        bullet("Promote value-added services with a retention effect (e.g. Online Security, Tech Support), which are associated with lower churn in the data, as part of upsell/retention conversations."),
        bullet("Re-score the customer base periodically (e.g. monthly) with the trained model so at-risk customers are identified before they churn, not after."),

        // ---------------- 10. CONCLUSION ----------------
        h1("10. Final Observations and Conclusion"),
        p("This project implemented a complete, reproducible machine-learning workflow spanning preprocessing, exploratory analysis, supervised classification, model evaluation/selection, unsupervised segmentation and dimensionality reduction on a real-world telecom churn dataset."),
        bullet(`Contract type, tenure and monthly charges are the strongest observed drivers of churn; month-to-month customers churn at a dramatically higher rate than customers on annual or two-year contracts.`),
        bullet(`Among five supervised models compared, ${summary.best_classification_model} gave the best F1-score (${summary.best_model_metrics["F1-score"]}) and a strong ROC-AUC (${summary.best_model_metrics["ROC-AUC"]}), making it the recommended model for this task, with the caveat that model choice should reflect the real business cost of false negatives vs false positives.`),
        bullet(`K-Means clustering with k = ${summary.chosen_k} (chosen via silhouette analysis) produced clearly interpretable, actionable segments, one of which shows a churn rate more than 1.6× the overall average and represents the highest-priority group for retention efforts.`),
        bullet("PCA confirmed that the chosen behavioural features separate customers into visually and statistically distinct groups, and that the highest-risk cluster spatially overlaps the region dominated by actual churners — validating the segmentation."),
        p("Overall, combining a predictive classification model with behavioural segmentation gives the business both a customer-level churn probability and a segment-level strategic lens, supporting both individualised interventions and broader retention-program design."),

        // ---------------- 11. GITHUB ----------------
        h1("11. GitHub Repository"),
        p("The complete working project — dataset reference, source code, requirements.txt, and generated outputs — is available at the following GitHub repository:"),
        p("[INSERT TEAM GITHUB REPOSITORY URL HERE BEFORE SUBMISSION]", { bold: true, color: "C00000" }),
        p("Repository contents: data/telco_churn.csv (dataset), code/churn_pipeline.py (full pipeline, single-command execution), requirements.txt, README.md (setup and run instructions, dataset source)."),

        new Paragraph({ children: [new PageBreak()] }),

        // ---------------- 12. INDIVIDUAL CONTRIBUTIONS ----------------
        h1("12. Individual Contribution Write-Up"),
        p("(One page per team member. Do not include names or register numbers in this document — refer to members generically, e.g. by role, as instructed. Replace the bracketed placeholders below for each member.)"),

        h2("Team Member 1"),
        bullet("Area(s) of contribution: [e.g. dataset preparation, preprocessing]"),
        bullet("Description of work performed: [describe specific tasks completed]"),
        bullet("Tools/techniques used: [e.g. pandas, StandardScaler]"),
        bullet("Challenges faced and how they were resolved: [describe]"),
        bullet("Approximate contribution: [e.g. 20%]"),

        h2("Team Member 2"),
        bullet("Area(s) of contribution: [e.g. exploratory analysis, model implementation]"),
        bullet("Description of work performed: [describe specific tasks completed]"),
        bullet("Tools/techniques used: [e.g. seaborn, scikit-learn classifiers]"),
        bullet("Challenges faced and how they were resolved: [describe]"),
        bullet("Approximate contribution: [e.g. 20%]"),

        h2("Team Member 3"),
        bullet("Area(s) of contribution: [e.g. evaluation, clustering, visualization]"),
        bullet("Description of work performed: [describe specific tasks completed]"),
        bullet("Tools/techniques used: [e.g. KMeans, PCA, matplotlib]"),
        bullet("Challenges faced and how they were resolved: [describe]"),
        bullet("Approximate contribution: [e.g. 20%]"),

        h2("Team Member 4"),
        bullet("Area(s) of contribution: [e.g. testing, documentation, GitHub management]"),
        bullet("Description of work performed: [describe specific tasks completed]"),
        bullet("Tools/techniques used: [e.g. GitHub, docx reporting]"),
        bullet("Challenges faced and how they were resolved: [describe]"),
        bullet("Approximate contribution: [e.g. 20%]"),

        p("(Add or remove member sections above to match the actual team size.)", { italics: true, color: "888888" }),
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  fs.writeFileSync("/home/claude/churn_project/outputs/Customer_Churn_Assignment_Report.docx", buffer);
  console.log("Report written.");
});
